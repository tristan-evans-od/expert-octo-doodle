             CMOS Save/Restore/Compare Utility v1.6b
               Copyright 2012 TOSHIBA Corporation


This README file contains information about the CMOS Save/Restore/Compare
Utility for the TOSHIBA SurePOS 700 Series.



CONTENTS
________

1.0  Supported systems
2.0  Usage
3.0  Notes
4.0  Trademarks and Notices



1.0  Supported systems
______________________

- TOSHIBA SurePOS 700 4800-723/E23,743/E43/C43,783/E83



2.0  USAGE
__________

This utility is commonly used to take a snapshot of one system's BIOS
settings ("master"), and then replicate the master's configuration to
a number of target systems ("target").

Command line options:
CMOS /B    :Backup  CMOS data to disk
CMOS /R    :Restore CMOS data from disk
CMOS /C    :Compare CMOS data from disk to motherboard CMOS
CMOS /?    :View CMOS utility command syntax
CMOS       :View CMOS data


CMOS /b
  Purpose: Backup CMOS data to file
  
  Description:
  This function backs up all CMOS data bytes (0-255) to file cmos.dat.

CMOS /r
  Purpose: Restore CMOS data from file
  
  Description:
  This function restores a saved CMOS data file into the system's CMOS.
  The supplied file csxxxxxx.map must exist in the current directory.

CMOS /c
  Purpose: Compare CMOS data from file to motherboard CMOS.
  
  Description:
  This function compares a CMOS data file with the current system's CMOS.
  The supplied file csxxxxxx.map must exist in the current directory.


Sample usage:
1. Take a snapshot of the master:
   - Configure master's BIOS settings as desired using the BIOS Setup utility
   - Boot the master from the diskette
   - Run "cmos /b" to save the master's CMOS data

2. Restore the master's snapshot to the target(s)
   - Copy the "cmos.dat" file from the master's diskette to the target's
     diskette
   - Boot the target(s) from the diskette
   - Run "cmos /r" to apply the master's CMOS settings
   - Reboot



3.0  Notes
__________

- CMOS data file is only applicable to the system model/type and BIOS on which
  it was created
- Parameters may be lower or uppercase
- This utility is designed for DOS and will not run under Microsoft(R)
  Windows(R)
- Only one parameter is accepted (ie, /r and /b can not be performed at the same
  time)
- The file csxxxxxx.map contains important CMOS filter information and must
  be present in the same directory as the CMOS utility



4.0  Trademarks and Notices
___________________________

The following terms are trademarks of the TOSHIBA Corporation in the
United States or other countries or both:

TOSHIBA
SurePOS

Other company, product, and service names may be trademarks or service
marks of others.


THIS DOCUMENT IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.  TOSHIBA
DISCLAIMS ALL WARRANTIES, WHETHER EXPRESS OR IMPLIED, INCLUDING
WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE AND MERCHANTABILITY WITH RESPECT TO THE INFORMATION IN THIS
DOCUMENT.  BY FURNISHING THIS DOCUMENT, TOSHIBA GRANTS NO LICENSES TO ANY
PATENTS OR COPYRIGHTS.

Note to U.S. Government Users -- Documentation related to restricted
rights -- Use, duplication or disclosure is subject to restrictions
set forth in GSA ADP Schedule Contract with TOSHIBA Corp.